// app.js

// --- RF-based linearised burnout equation ---
// (NOTE: these are surrogate/linearised coefficients, NOT RF feature importances)
function predictBurnout(MF, RA, DES, WH, DP, CT, SH, MS, WFH, TS, WLB, REC) {
  let y =
    0.374627 +
    0.030642 * MF +   // Mental_Fatigue_Score
    0.00498  * RA +   // Resource_Allocation
    0.003885 * DES +  // Designation
    0.00059  * WH +   // Work_Hours_per_Week
    0.00287  * DP +   // Deadline_Pressure_Score
    0.000556 * CT +   // Company_Type
    0.000041 * SH +   // Sleep_Hours
    0.000007 * MS -   // Manager_Support_Score (tiny)
    0.00268  * WFH -  // WFH_Setup_Available (1=yes)
    0.000221 * TS -   // Team_Size
    0.007179 * WLB -  // Work_Life_Balance_Score
    0.008873 * REC;   // Recognition_Frequency

  // Clamp between 0 and 1
  y = Math.max(0, Math.min(1, y));
  return y;
}

window.addEventListener("load", () => {
  console.log("app.js loaded and DOM ready");

  // ---- DOM references ----
  const sliderValueMap = {
    sleepHours: "sleepHoursValue",
    mentalFatigue: "mentalFatigueValue",
    workLifeBalance: "workLifeBalanceValue",
    managerSupport: "managerSupportValue",
    recognitionFrequency: "recognitionFrequencyValue",
    workHours: "workHoursValue",
    deadlinePressure: "deadlinePressureValue",
    resourceAllocation: "resourceAllocationValue",
    teamSize: "teamSizeValue",
  };

  const scoreDisplay   = document.getElementById("burnoutScoreDisplay");
  const categoryLabel  = document.getElementById("riskCategoryLabel");
  const categoryCard   = document.getElementById("riskCategoryCard");
  const insightText    = document.getElementById("insightText");

  if (!scoreDisplay || !categoryLabel || !categoryCard || !insightText) {
    console.error("One or more key elements are missing from the DOM.");
    return;
  }

  // ✅ UPDATED thresholds from your RF predicted quartiles
  const LOW_CUTOFF  = 0.321;  // Q1 (25%)
  const HIGH_CUTOFF = 0.585;  // Q3 (75%)

  function getNumber(id) {
    const el = document.getElementById(id);
    if (!el) {
      console.warn("Element not found:", id);
      return 0;
    }
    return parseFloat(el.value) || 0;
  }

  function getRadioValue(name) {
    const el = document.querySelector(`input[name="${name}"]:checked`);
    return el ? parseFloat(el.value) : 0;
  }

  // --- Update small value labels next to sliders ---
  function updateSliderLabels() {
    Object.entries(sliderValueMap).forEach(([sliderId, spanId]) => {
      const slider = document.getElementById(sliderId);
      const span   = document.getElementById(spanId);
      if (!slider || !span) return;

      const value = parseFloat(slider.value);

      if (sliderId === "sleepHours") {
        span.textContent = `${value.toFixed(1)} h`;
      } else if (sliderId === "workHours") {
        span.textContent = `${value.toFixed(0)} h`;
      } else {
        span.textContent = Number.isInteger(value)
          ? value.toFixed(0)
          : value.toFixed(1);
      }
    });
  }

  // ✅ Threshold highlight (make sure your HTML has thrLow/thrMod/thrHigh)
  function highlightThreshold(score) {
    const low = document.getElementById("thrLow");
    const mod = document.getElementById("thrMod");
    const high = document.getElementById("thrHigh");
    [low, mod, high].forEach(el => el && el.classList.remove("active"));

    if (score <= LOW_CUTOFF) low && low.classList.add("active");
    else if (score < HIGH_CUTOFF) mod && mod.classList.add("active");
    else high && high.classList.add("active");
  }

  // --- Main prediction + UI update ---
  function updatePrediction() {
    updateSliderLabels();

    // Read inputs
    const SH  = getNumber("sleepHours");
    const MF  = getNumber("mentalFatigue");
    const WLB = getNumber("workLifeBalance");
    const MS  = getNumber("managerSupport");
    const REC = getNumber("recognitionFrequency");

    const WH  = getNumber("workHours");
    const DP  = getNumber("deadlinePressure");
    const RA  = getNumber("resourceAllocation");
    const TS  = getNumber("teamSize");

    const DES = parseFloat(document.getElementById("designationSelect").value) || 0;
    const CT  = getRadioValue("companyType"); // 0 or 1
    const WFH = getRadioValue("wfh");         // 1 or 0

    const y = predictBurnout(MF, RA, DES, WH, DP, CT, SH, MS, WFH, TS, WLB, REC);

    // Update score
    scoreDisplay.textContent = y.toFixed(3);

    // ✅ highlight threshold card
    highlightThreshold(y);

    // Risk band
    let category, cssClass;
    if (y <= LOW_CUTOFF) {
      category = `Low (≤ ${LOW_CUTOFF.toFixed(3)})`;
      cssClass = "risk-low";
    } else if (y < HIGH_CUTOFF) {
      category = `Moderate (${LOW_CUTOFF.toFixed(3)}–${HIGH_CUTOFF.toFixed(3)})`;
      cssClass = "risk-moderate";
    } else {
      category = `High (≥ ${HIGH_CUTOFF.toFixed(3)})`;
      cssClass = "risk-high";
    }

    categoryLabel.textContent = category;
    categoryCard.classList.remove("risk-low", "risk-moderate", "risk-high");
    categoryCard.classList.add(cssClass);

    // Insight text
    let insight;
    if (y >= HIGH_CUTOFF) {
      insight = "High burnout risk. Priority: reduce work hours and deadline pressure, while improving work–life balance and recognition.";
    } else if (y > LOW_CUTOFF) {
      insight = "Moderate burnout risk. Improving work–life balance and recognition could meaningfully reduce this score.";
    } else {
      insight = "Low burnout risk. Maintain healthy sleep, reasonable work hours, and consistent recognition/support.";
    }

    if (MF >= 8) insight += " Mental fatigue is very high here—recovery time/workload changes matter a lot.";
    if (REC <= 1) insight += " Recognition is low—more frequent appreciation may buffer burnout risk.";
    if (WLB <= 2) insight += " Work–life balance is poor—boundaries/flexibility may help.";

    insightText.textContent = insight;
  }

  // --- Attach event listeners ---
  Object.keys(sliderValueMap).forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", updatePrediction);
  });

  const designationSelect = document.getElementById("designationSelect");
  if (designationSelect) designationSelect.addEventListener("change", updatePrediction);

  document.querySelectorAll('input[name="companyType"]').forEach((el) =>
    el.addEventListener("change", updatePrediction)
  );
  document.querySelectorAll('input[name="wfh"]').forEach((el) =>
    el.addEventListener("change", updatePrediction)
  );

  // Initial calculation
  updatePrediction();
});
